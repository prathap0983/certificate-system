const Certificate = {
  certificates: [],
  templates: [],

  init() {
    this.certificates = Utils.getFromStorage('certificates') || [];
    this.templates = Utils.getFromStorage('templates') || [];
    this.setupForm();
    this.setupLivePreview();
    this.setupTemplateSelector();
    this.setupGenerate();
    this.autoFillCertificateNumber();
    this.setupTemplatePreviewSync();
  },

  setupTemplatePreviewSync() {
    const templateSelect = document.getElementById('certTemplate');
    if (templateSelect) {
      templateSelect.addEventListener('change', () => {
        if (document.getElementById('livePreview')) {
          this.updateLivePreview();
        }
      });
    }
  },

  initPreview() {
    this.templates = Utils.getFromStorage('templates') || [];
    const params = new URLSearchParams(window.location.search);
    const certId = params.get('id');
    if (certId) {
      this.loadCertificate(certId);
    } else {
      const data = Utils.getFromStorage('previewData');
      if (data) {
        this.renderPreview(data);
        Utils.removeFromStorage('previewData');
      }
    }
    this.setupPreviewButtons();
  },

  setupForm() {
    const form = document.getElementById('certificateForm');
    if (!form) return;
    const students = Utils.getFromStorage('students') || [];
    const studentSelect = document.getElementById('certStudentSelect');

    if (studentSelect && students.length) {
      studentSelect.innerHTML = `<option value="">Select existing student...</option>
        ${students.map(s => `<option value="${s.id}">${s.name} (${s.registerNumber}) - ${s.studentType || 'Internship'}</option>`).join('')}`;
      studentSelect.addEventListener('change', (e) => {
        const student = students.find(s => s.id === e.target.value);
        if (student) {
          document.getElementById('certStudentName').value = student.name || '';
          document.getElementById('certRegisterNumber').value = student.registerNumber || '';
          document.getElementById('certCollege').value = student.college || '';
          document.getElementById('certDepartment').value = student.department || '';
          document.getElementById('certDuration').value = student.duration || '';
          document.getElementById('certStartDate').value = student.startDate || '';
          document.getElementById('certEndDate').value = student.endDate || '';
          const type = student.studentType || 'Internship';
          const internshipGroup = document.getElementById('certInternshipGroup');
          const courseGroup = document.getElementById('certCourseGroup');
          if (type === 'Internship') {
            document.getElementById('certInternshipTitle').value = student.internshipTitle || '';
            document.getElementById('certCourse').value = '';
            if (courseGroup) courseGroup.style.display = 'none';
            if (internshipGroup) internshipGroup.style.display = 'block';
          } else {
            document.getElementById('certCourse').value = student.course || '';
            document.getElementById('certInternshipTitle').value = '';
            if (internshipGroup) internshipGroup.style.display = 'none';
            if (courseGroup) courseGroup.style.display = 'block';
          }
          this.updateLivePreview();
        } else {
          const internshipGroup = document.getElementById('certInternshipGroup');
          const courseGroup = document.getElementById('certCourseGroup');
          if (internshipGroup) internshipGroup.style.display = 'block';
          if (courseGroup) courseGroup.style.display = 'block';
        }
      });
    }
  },

  setupTemplateSelector() {
    this.templates = Utils.getFromStorage('templates') || [];
    const template = document.getElementById('certTemplate');
    if (!template) return;
    template.innerHTML = `<option value="">Select template...</option>
      ${this.templates.filter(t => t.status === 'Active').map(t => `<option value="${t.id}">${t.name} (${t.orientation})</option>`).join('')}`;
    template.addEventListener('change', () => {
      this.updateLivePreview();
    });
  },

  setupLivePreview() {
    const fields = ['studentName', 'registerNumber', 'college', 'department', 'course', 'internshipTitle', 'duration', 'startDate', 'endDate', 'issueDate', 'certificateNumber'];
    fields.forEach(f => {
      const el = document.getElementById(`cert${f.charAt(0).toUpperCase() + f.slice(1)}`);
      if (el) el.addEventListener('input', () => this.updateLivePreview());
    });
    const internshipInput = document.getElementById('certInternshipTitle');
    if (internshipInput) internshipInput.addEventListener('input', () => this.updateLivePreview());
    const courseInput = document.getElementById('certCourse');
    if (courseInput) courseInput.addEventListener('input', () => this.updateLivePreview());
  },

  updateLivePreview() {
    const data = this.getFormData();
    this.renderPreview(data);
  },

  getFormData() {
    const get = (id) => (document.getElementById(id) || {}).value || '';
    const studentType = (() => {
      const sel = document.getElementById('certStudentSelect');
      if (!sel) return 'Internship';
      const students = Utils.getFromStorage('students') || [];
      const s = students.find(st => st.id === sel.value);
      return s ? (s.studentType || 'Internship') : 'Internship';
    })();
    return {
      studentName: get('certStudentName'),
      registerNumber: get('certRegisterNumber'),
      college: get('certCollege'),
      department: get('certDepartment'),
      course: get('certCourse'),
      internshipTitle: get('certInternshipTitle'),
      duration: get('certDuration'),
      startDate: get('certStartDate'),
      endDate: get('certEndDate'),
      issueDate: get('certIssueDate'),
      certificateNumber: get('certCertificateNumber'),
      templateId: get('certTemplate'),
      studentType: studentType
    };
  },

  getTemplateById(id) {
    if (!id) return null;
    this.templates = Utils.getFromStorage('templates') || [];
    return this.templates.find(t => t.id === id) || null;
  },

  replaceVariables(text, data, company) {
    const studentType = data.studentType || 'Internship';
    const programTitle = studentType === 'Internship' ? (data.internshipTitle || 'Internship Program') : (data.course || 'Course Program');
    const vars = {
      '{{StudentName}}': data.studentName || 'Student Name',
      '{{RegisterNumber}}': data.registerNumber || 'REG-001',
      '{{College}}': data.college || 'College Name',
      '{{Department}}': data.department || 'Department',
      '{{Course}}': data.course || 'Course',
      '{{InternshipTitle}}': data.internshipTitle || 'Internship Program',
      '{{Duration}}': data.duration || '3 Months',
      '{{StartDate}}': Utils.formatDate(data.startDate) || 'Start Date',
      '{{EndDate}}': Utils.formatDate(data.endDate) || 'End Date',
      '{{IssueDate}}': Utils.formatDate(data.issueDate) || new Date().toLocaleDateString(),
      '{{CertificateID}}': data.certificateNumber || 'STC20260001',
      '{{CompanyName}}': company,
      '{{GuideName}}': '',
      '{{StudentType}}': studentType,
      '{{ProgramTitle}}': programTitle,
      '{{QR}}': '<div class="certificate-qr" style="display:inline-flex;width:70px;height:70px;background:#F3F4F6;border-radius:8px;align-items:center;justify-content:center;font-size:32px;color:#9CA3AF"><i class="fas fa-qrcode"></i></div>'
    };
    let result = text;
    Object.keys(vars).forEach(key => {
      result = result.replace(new RegExp(key.replace(/[{}]/g, '\\$&'), 'g'), vars[key]);
    });
    return result;
  },

  renderPreview(data) {
    const container = document.getElementById('livePreview');
    if (!container) return;

    // Get template with fallback chain
    let tpl = data.templateSnapshot || null;
    if (!tpl || !tpl.elements || tpl.elements.length === 0) {
      const liveTpl = this.getTemplateById(data.templateId);
      if (liveTpl && liveTpl.elements && liveTpl.elements.length > 0) {
        tpl = liveTpl;
      }
    }
    if (!tpl) {
      tpl = data.templateSnapshot || this.getTemplateById(data.templateId);
    }

    const orientation = tpl && tpl.orientation ? tpl.orientation : 'Landscape';
    const isPortrait = orientation === 'Portrait';
    const settings = Utils.getFromStorage('settings') || { companyName: 'Samudhra Tech Solutions' };

    // Fixed canvas dimensions matching the designer canvas (respect paperSize)
    const paperSize = (tpl && tpl.paperSize) || 'A4';
    const isLetter = paperSize === 'Letter';
    let canvasW, canvasH;
    if (isLetter) {
      canvasW = isPortrait ? 850 : 1100;
      canvasH = isPortrait ? 1100 : 850;
    } else {
      canvasW = isPortrait ? 794 : 1123;
      canvasH = isPortrait ? 1123 : 794;
    }

    const validElements = tpl && tpl.elements ? tpl.elements.filter(el => el.visible !== false) : [];
    const canRenderDesigner = validElements.length > 0;

    if (canRenderDesigner) {
      const bg = tpl.bgConfig || {};
      const bgStyle = bg.type === 'gradient' && bg.gradient ? bg.gradient : bg.color || '#FFFFFF';

      // Build elements HTML (same positioning as designer renderCanvas)
      let elementsHTML = '';
      validElements.forEach(item => {
        const opacity = item.opacity !== undefined ? item.opacity : 1.0;
        if (item.type === 'text') {
          const replacedContent = this.replaceVariables(item.content, data, settings.companyName);
          elementsHTML += `
            <div style="
              position: absolute;
              left: ${item.x}px;
              top: ${item.y}px;
              width: ${item.width}px;
              height: ${item.height}px;
              transform: rotate(${item.rotation || 0}deg);
              opacity: ${opacity};
              font-family: '${item.fontFamily}', sans-serif;
              font-size: ${item.fontSize}px;
              font-weight: ${item.fontWeight};
              font-style: ${item.fontStyle};
              text-decoration: ${item.textDecoration};
              color: ${item.color};
              text-align: ${item.textAlign};
              letter-spacing: ${item.letterSpacing}px;
              line-height: ${item.lineHeight};
              text-transform: ${item.textTransform};
              text-shadow: ${item.textShadow || 'none'};
              border: ${item.borderWidth ? item.borderWidth + 'px solid ' + (item.borderColor || '#000') : 'none'};
              border-radius: ${item.borderRadius || 0}px;
            ">${replacedContent}</div>`;
        } else if (item.type === 'image') {
          const imgSrc = item.content && item.content.startsWith('data:') ? item.content : '';
          elementsHTML += `
            <img src="${imgSrc || 'https://via.placeholder.com/' + item.width + 'x' + item.height + '?text=' + (item.placeholder || 'Image')}"
              style="
                position: absolute;
                left: ${item.x}px;
                top: ${item.y}px;
                width: ${item.width}px;
                height: ${item.height}px;
                transform: rotate(${item.rotation || 0}deg);
                opacity: ${opacity};
                object-fit: contain;
              " />`;
        }
      });

      const borderVal = bg.borderWidth ? bg.borderWidth + 'px ' + (bg.borderStyle || 'solid') + ' ' + (bg.borderColor || '#1565C0') : 'none';

      // Watermark rendering (same as applyBackgroundConfig)
      let watermarkHTML = '';
      if (bg.watermark && bg.watermarkVisible !== false) {
        const wmW = bg.watermarkWidth || 200;
        const wmH = bg.watermarkHeight || 200;
        const wmScale = (bg.watermarkScale || 100) / 100;
        const wmX = bg.watermarkX != null ? bg.watermarkX + 'px' : '50%';
        const wmY = bg.watermarkY != null ? bg.watermarkY + 'px' : '50%';
        watermarkHTML = `<img src="${bg.watermark}" style="
          position: absolute;
          left: ${wmX};
          top: ${wmY};
          width: ${wmW}px;
          height: ${wmH}px;
          opacity: ${bg.watermarkOpacity || 0.15};
          transform: translate(-50%, -50%) rotate(${bg.watermarkRotation || 0}deg) scale(${wmScale});
          pointer-events: none;
        ">`;
      }

      // Build fixed-dimension A4 canvas (identical coordinate space to designer)
      const canvasHTML = `
        <div class="certificate-a4-canvas" id="certificateDisplay"
          style="
            width: ${canvasW}px;
            height: ${canvasH}px;
            position: relative;
            overflow: hidden;
            background: ${bgStyle};
            background-size: ${bg.size || 'cover'};
            background-position: center;
            background-repeat: ${bg.size === 'repeat' ? 'repeat' : 'no-repeat'};
            ${bg.image ? `background-image: url('${bg.image}');` : ''}
            opacity: ${bg.opacity || 1.0};
            ${(bg.borderWidth || 0) > 0 ? `border: ${borderVal};` : ''}
            box-sizing: border-box;
            margin: 0 auto;
          ">
          ${watermarkHTML}
          ${elementsHTML}
        </div>`;

      // Wrap in a container that scales the A4 canvas to fit the viewport
      container.innerHTML = `
        <div class="certificate-preview" style="position:relative;width:100%;overflow:hidden;background:transparent;box-shadow:none;border-radius:0;">
          <div class="certificate-scaler" style="display:flex;justify-content:center;align-items:flex-start;overflow:hidden;">
            ${canvasHTML}
          </div>
        </div>`;

      // Apply automatic scaling so the A4 canvas fits the preview area
      const scaler = container.querySelector('.certificate-scaler');
      const a4canvas = container.querySelector('.certificate-a4-canvas');
      this._fitCanvasToViewport(a4canvas, scaler, canvasW, canvasH);

      return;
    }

    // Fallback default preview (no designer template)
    container.innerHTML = `
      <div class="certificate-preview" id="certificateDisplay">
        <div class="certificate-inner ${isPortrait ? 'portrait' : 'landscape'}">
          <div class="certificate-company">${settings.companyName || 'SAMUDHRA TECH SOLUTIONS'}</div>
          <div class="certificate-title">${tpl ? tpl.name : 'Certificate of Completion'}</div>
          <div class="certificate-text">This is to certify that</div>
          <div class="certificate-student-name">${data.studentName || 'Student Name'}</div>
          <div class="certificate-text">
            has successfully completed the internship program in
            <strong>${data.internshipTitle || 'Program'}</strong>
            from ${Utils.formatDate(data.startDate) || 'Start Date'} to ${Utils.formatDate(data.endDate) || 'End Date'}
          </div>
          <div class="certificate-details">
            ${[['Register No', data.registerNumber], ['College', data.college], ['Department', data.department], ['Course', data.course], ['Duration', data.duration]].map(([l, v]) => v ? `
              <div class="certificate-detail-item">
                <div class="certificate-detail-label">${l}</div>
                <div class="certificate-detail-value">${v}</div>
              </div>` : '').join('')}
          </div>
          <div class="certificate-footer">
            <div class="certificate-signature">
              <div class="certificate-signature-line"></div>
              <div class="certificate-signature-name">Authorized Signature</div>
              <div class="certificate-signature-role">${settings.companyName || 'Samudhra Tech Solutions'}</div>
            </div>
            <div class="certificate-qr">
              <i class="fas fa-qrcode"></i>
            </div>
          </div>
          <div class="certificate-issue-date">Issue Date: ${Utils.formatDate(data.issueDate) || 'Today'}</div>
          <div class="certificate-number">#${data.certificateNumber || 'STC20260001'}</div>
        </div>
      </div>
    `;
  },

  _fitCanvasToViewport(canvas, scaler, w, h) {
    const doFit = () => {
      const parentW = scaler.clientWidth || 800;
      const viewH = window.innerHeight * 0.65;
      const scale = Math.min(parentW / w, viewH / h, 1.0);
      canvas.style.transform = `scale(${scale})`;
      canvas.style.transformOrigin = 'top center';
      // Adjust scaler height to match visual canvas height (prevent layout gap)
      scaler.style.height = `${Math.ceil(h * scale)}px`;
    };
    doFit();
    if (this._fitHandler) window.removeEventListener('resize', this._fitHandler);
    this._fitHandler = doFit;
    window.addEventListener('resize', this._fitHandler);
  },

  setupGenerate() {
    const btn = document.getElementById('generateCertificate');
    if (!btn) return;
    btn.addEventListener('click', () => {
      const data = this.getFormData();
      if (!data.studentName || !data.certificateNumber) {
        showToast('Validation Error', 'Student name and certificate number are required', 'error');
        return;
      }
      if (!data.templateId) {
        showToast('Validation Error', 'Please select a template', 'error');
        return;
      }

      // Capture a snapshot of the selected template at generation time
      const tpl = this.getTemplateById(data.templateId);
      if (!tpl) {
        showToast('Validation Error', 'Selected template not found', 'error');
        return;
      }

      const cert = {
        id: Utils.generateId(),
        ...data,
        templateSnapshot: JSON.parse(JSON.stringify(tpl)),
        status: 'Valid',
        createdAt: new Date().toISOString()
      };
      this.certificates.unshift(cert);
      Utils.setToStorage('certificates', this.certificates);
      showToast('Success', 'Certificate generated successfully', 'success');
      setTimeout(() => Utils.navigateTo(`preview.html?id=${cert.id}`), 1000);
    });
  },

  loadCertificate(id) {
    this.certificates = Utils.getFromStorage('certificates') || [];
    this.templates = Utils.getFromStorage('templates') || [];
    const cert = this.certificates.find(c => c.id === id);
    if (cert) {
      this.renderPreview(cert);
    }
  },

  setupPreviewButtons() {
    const printBtn = document.getElementById('printCertificate');
    if (printBtn) {
      printBtn.addEventListener('click', () => Utils.printElement('certificateDisplay'));
    }
    const downloadBtn = document.getElementById('downloadCertificate');
    if (downloadBtn) {
      downloadBtn.addEventListener('click', () => {
        const num = (document.querySelector('.certificate-number') || {}).textContent || 'certificate';
        Utils.downloadPDF('certificateDisplay', num.replace('#', ''));
      });
    }
  },

  autoFillCertificateNumber() {
    const el = document.getElementById('certCertificateNumber');
    if (el && !el.value) el.value = Utils.generateCertificateNumber();
    const issueEl = document.getElementById('certIssueDate');
    if (issueEl && !issueEl.value) issueEl.value = new Date().toISOString().split('T')[0];
  },

  /* === Bulk Generation === */
  initBulk() {
    this.setupBulkUpload();
  },

  setupBulkUpload() {
    const area = document.getElementById('bulkUploadArea');
    if (!area) return;
    area.addEventListener('click', () => {
      showToast('Info', 'Upload Excel file (placeholder). Backend integration required for actual file processing.', 'info');
    });
  }
};

/* === Verification Page === */
const Verification = {
  certificates: [],

  init() {
    this.certificates = Utils.getFromStorage('certificates') || [];
    this.setupVerification();
  },

  setupVerification() {
    const btn = document.getElementById('verifyBtn');
    const input = document.getElementById('verifyInput');
    if (!btn || !input) return;
    btn.addEventListener('click', () => this.verify(input.value.trim()));
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') this.verify(input.value.trim()); });
  },

  verify(query) {
    const result = document.getElementById('verificationResult');
    if (!query) {
      showToast('Info', 'Please enter a certificate number or student name', 'warning');
      return;
    }
    const cert = this.certificates.find(c =>
      c.certificateNumber === query ||
      (c.studentName && c.studentName.toLowerCase().includes(query.toLowerCase()))
    );
    if (!result) return;

    if (cert) {
      const certType = cert.studentType || 'Internship';
      const programField = certType === 'Internship' ? cert.internshipTitle : cert.course;
      result.className = 'verification-result valid';
      result.innerHTML = `
        <div class="verification-icon"><i class="fas fa-check-circle"></i></div>
        <div class="verification-status">Valid Certificate</div>
        <p style="color:var(--text-secondary);margin-bottom:16px">This certificate has been verified and is authentic.</p>
        <div class="verification-details">
          <div><strong>Student:</strong> ${cert.studentName}</div>
          <div><strong>Certificate No:</strong> ${cert.certificateNumber}</div>
          <div><strong>Program:</strong> ${programField || 'N/A'}</div>
          <div><strong>Type:</strong> ${certType}</div>
          <div><strong>Issue Date:</strong> ${Utils.formatDate(cert.issueDate)}</div>
          <div><strong>College:</strong> ${cert.college || 'N/A'}</div>
          <div><strong>Status:</strong> <span class="badge badge-success">Verified</span></div>
        </div>
        <button class="btn btn-primary" style="margin-top:24px" onclick="Utils.downloadPDF('verificationResult', '${cert.certificateNumber}')">
          <i class="fas fa-download"></i> Download Certificate
        </button>
      `;
    } else {
      result.className = 'verification-result invalid';
      result.innerHTML = `
        <div class="verification-icon"><i class="fas fa-times-circle"></i></div>
        <div class="verification-status">Invalid Certificate</div>
        <p style="color:var(--text-secondary)">No certificate found matching "<strong>${query}</strong>". Please verify the information and try again.</p>
      `;
    }
  }
};

window.Certificate = Certificate;
window.Verification = Verification;