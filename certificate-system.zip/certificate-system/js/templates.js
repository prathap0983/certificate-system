/* ==========================================================================
   TEMPLATES MANAGEMENT WITH VISUAL DESIGNER INTEGRATION (js/templates.js)
   ========================================================================== */

const Templates = {
  templates: [],
  filtered: [],
  searchTerm: '',
  filterCategory: '',
  sortBy: 'newest',

  init() {
    this.loadTemplates();
    this.render();
    this.setupEventListeners();
  },

  loadTemplates() {
    this.templates = Utils.getFromStorage('templates') || [];
    if (!this.templates.length) {
      this.templates = this.getDefaultTemplates();
      Utils.setToStorage('templates', this.templates);
    }
    this.applyFilters();
  },

  getDefaultTemplates() {
    // Basic pre-populated templates with default canvas items
    return [
      {
        id: 'tpl_1',
        name: 'Internship Certificate',
        category: 'Internship',
        description: 'Standard internship completion certificate',
        orientation: 'Landscape',
        paperSize: 'A4',
        status: 'Active',
        createdAt: '2026-01-15',
        lastUpdated: '2026-01-15',
        bgConfig: {
          type: 'gradient',
          color: '#FFFFFF',
          gradient: 'linear-gradient(135deg, #F5F9FF 0%, #E3F2FD 100%)',
          opacity: 1.0,
          image: '',
          size: 'cover',
          borderWidth: 0,
          borderColor: '#1565C0',
          borderStyle: 'double',
          watermark: '', watermarkOpacity: 0.15,
          watermarkWidth: 200, watermarkHeight: 200, watermarkScale: 100,
          watermarkAspectRatio: true, watermarkRotation: 0,
          watermarkX: null, watermarkY: null,
          watermarkVisible: true, watermarkLocked: false
        },
        elements: [] // Loaded on designer init if empty
      },
      {
        id: 'tpl_2',
        name: 'Course Certificate',
        category: 'Course',
        description: 'Course completion certificate',
        orientation: 'Landscape',
        paperSize: 'A4',
        status: 'Active',
        createdAt: '2026-02-20',
        lastUpdated: '2026-02-20',
        bgConfig: {
          type: 'color',
          color: '#FFF9E6',
          opacity: 1.0,
          image: '',
          size: 'cover',
          borderWidth: 0,
          borderColor: '#F59E0B',
          borderStyle: 'solid',
          watermark: '', watermarkOpacity: 0.1,
          watermarkWidth: 200, watermarkHeight: 200, watermarkScale: 100,
          watermarkAspectRatio: true, watermarkRotation: 0,
          watermarkX: null, watermarkY: null,
          watermarkVisible: true, watermarkLocked: false
        },
        elements: []
      }
    ];
  },

  applyFilters() {
    let result = [...this.templates];
    if (this.searchTerm) {
      const term = this.searchTerm.toLowerCase();
      result = result.filter(t => 
        t.name.toLowerCase().includes(term) || 
        t.category.toLowerCase().includes(term) || 
        t.description.toLowerCase().includes(term)
      );
    }
    if (this.filterCategory) {
      result = result.filter(t => t.category === this.filterCategory);
    }
    if (this.sortBy === 'newest') result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    else if (this.sortBy === 'oldest') result.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    else if (this.sortBy === 'alpha') result.sort((a, b) => a.name.localeCompare(b.name));
    this.filtered = result;
  },

  render() {
    this.renderGrid();
    this.renderCategories();
  },

  renderGrid() {
    const container = document.getElementById('templateGrid');
    if (!container) return;

    if (!this.filtered.length) {
      container.innerHTML = `
        <div class="empty-state" style="grid-column:1/-1">
          <div class="empty-state-icon"><i class="fas fa-layer-group"></i></div>
          <h3>No Certificate Templates Available</h3>
          <p>${this.searchTerm ? 'Try adjusting your search or filters.' : 'Create your first template to get started.'}</p>
          ${!this.searchTerm ? '<button class="btn btn-primary" onclick="Templates.openAddModal()"><i class="fas fa-plus"></i> Create Template</button>' : ''}
        </div>`;
      return;
    }

    const categoryIcons = { 
      Internship: 'fas fa-briefcase', 
      Course: 'fas fa-graduation-cap'
    };

    container.innerHTML = this.filtered.map(t => {
      const orientIcon = t.orientation === 'Portrait' ? 'fa-portrait' : 'fa-image';
      
      let badgeClass = 'badge-primary';
      if (t.status === 'Active') badgeClass = 'badge-success';
      else if (t.status === 'Draft') badgeClass = 'badge-warning';
      else if (t.status === 'Archived') badgeClass = 'badge-error';

      const previewStyle = t.bgConfig && t.bgConfig.type === 'gradient' ? 
        `background: ${t.bgConfig.gradient}` : 
        `background: ${t.bgConfig ? t.bgConfig.color : '#E3F2FD'}`;

      return `
        <div class="template-card animate-on-load">
          <div class="template-preview" style="${previewStyle}">
            ${t.bgConfig && t.bgConfig.image ? `<img src="${t.bgConfig.image}" class="template-preview-bg" alt="">` : ''}
            <div class="template-preview-content">
              <i class="${categoryIcons[t.category] || 'fas fa-file-alt'}"></i>
            </div>
          </div>
          <div class="template-body">
            <div class="template-name">${t.name}</div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
              <span class="badge badge-primary">${t.category}</span>
              <span style="font-size:12px; color:var(--text-muted);"><i class="fas ${orientIcon}"></i> ${t.orientation} (${t.paperSize || 'A4'})</span>
            </div>
            <div class="template-meta" style="margin-top:8px;">
              <span>Updated: ${Utils.formatDate(t.lastUpdated || t.createdAt)}</span>
              <span class="badge ${badgeClass}">${t.status}</span>
            </div>
          </div>
          <div class="template-actions">
            <button class="btn btn-sm btn-secondary" onclick="Templates.previewTemplate('${t.id}')" title="Preview"><i class="fas fa-eye"></i></button>
            <button class="btn btn-sm btn-primary" onclick="Templates.openDesigner('${t.id}')" title="Customize Canvas / Design Template"><i class="fas fa-magic"></i> Design</button>
            <button class="btn btn-sm btn-outline" onclick="Templates.duplicateTemplate('${t.id}')" title="Duplicate"><i class="fas fa-copy"></i></button>
            <button class="btn btn-sm btn-outline" style="margin-left:auto" onclick="Templates.confirmDelete('${t.id}')" title="Delete"><i class="fas fa-trash" style="color:var(--error)"></i></button>
          </div>
        </div>
      `;
    }).join('');
  },

  renderCategories() {
    const container = document.getElementById('templateCategories');
    if (!container) return;
    const cats = [...new Set(this.templates.map(t => t.category))];
    container.innerHTML = `
      <div class="tabs">
        <button class="tab ${!this.filterCategory ? 'active' : ''}" onclick="Templates.filterByCategory('')">All</button>
        ${cats.map(c => `
          <button class="tab ${this.filterCategory === c ? 'active' : ''}" onclick="Templates.filterByCategory('${c}')">${c}</button>
        `).join('')}
      </div>
    `;
  },

  filterByCategory(cat) {
    this.filterCategory = cat;
    this.applyFilters();
    this.render();
  },

  setupEventListeners() {
    const search = document.getElementById('templateSearch');
    if (search) {
      search.addEventListener('input', Utils.debounce((e) => {
        this.searchTerm = e.target.value;
        this.applyFilters();
        this.render();
      }));
    }
    const sort = document.getElementById('templateSort');
    if (sort) {
      sort.addEventListener('change', (e) => {
        this.sortBy = e.target.value;
        this.applyFilters();
        this.render();
      });
    }
  },

  openAddModal() { 
    this.openTemplateModal(); 
  },

  openEditModal(id) {
    // We direct edits straight to the full-screen interactive visual canvas editor
    this.openDesigner(id);
  },

  openDesigner(id) {
    const tpl = this.templates.find(t => t.id === id);
    if (tpl) {
      Designer.init(tpl);
    }
  },

  openTemplateModal(template = null) {
    const modal = document.getElementById('templateModal');
    const title = document.getElementById('templateModalTitle');
    if (!modal) return;
    title.textContent = template ? 'Edit Template' : 'Create Custom Template';
    const fields = ['name', 'category', 'description', 'orientation', 'paperSize', 'status'];
    fields.forEach(f => {
      const el = document.getElementById(`template${Utils.capitalize(f)}`);
      if (el) el.value = template ? (template[f] || '') : '';
    });
    modal.dataset.editId = template ? template.id : '';
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  },

  saveTemplate() {
    const modal = document.getElementById('templateModal');
    const id = modal.dataset.editId;
    const fields = ['name', 'category', 'description', 'orientation', 'paperSize', 'status'];
    const data = {};
    fields.forEach(f => {
      const el = document.getElementById(`template${Utils.capitalize(f)}`);
      data[f] = el ? el.value : '';
    });

    if (!data.name || !data.category) {
      showToast('Validation Error', 'Template name and category are required', 'error');
      return;
    }

    let targetTemplate;

    if (id) {
      const idx = this.templates.findIndex(t => t.id === id);
      if (idx >= 0) {
        this.templates[idx] = { ...this.templates[idx], ...data };
        targetTemplate = this.templates[idx];
      }
      showToast('Updated', 'Template basic details saved successfully', 'success');
    } else {
      data.id = Utils.generateId();
      data.createdAt = new Date().toISOString().split('T')[0];
      data.lastUpdated = data.createdAt;
      
      // Setup default background config
      data.bgConfig = {
        type: 'gradient',
        color: '#FFFFFF',
        gradient: 'linear-gradient(135deg, #F5F9FF 0%, #E3F2FD 100%)',
        opacity: 1.0,
        image: '',
        size: 'cover',
        borderWidth: 0,
        borderColor: '#1565C0',
        borderStyle: 'double',
        watermark: '', watermarkOpacity: 0.15,
        watermarkWidth: 200, watermarkHeight: 200, watermarkScale: 100,
        watermarkAspectRatio: true, watermarkRotation: 0,
        watermarkX: null, watermarkY: null,
        watermarkVisible: true, watermarkLocked: false
      };
      
      data.elements = []; // Will be populated in designer
      
      this.templates.unshift(data);
      targetTemplate = data;
      showToast('Created', 'New template registered', 'success');
    }

    Utils.setToStorage('templates', this.templates);
    modal.classList.remove('active');
    document.body.style.overflow = '';
    
    this.applyFilters();
    this.render();

    // Automatically trigger Visual Canvas Designer overlay for brand new templates
    if (targetTemplate) {
      setTimeout(() => {
        this.openDesigner(targetTemplate.id);
      }, 500);
    }
  },

  previewTemplate(id) {
    const tpl = this.templates.find(t => t.id === id);
    if (!tpl) return;
    const modal = document.getElementById('templatePreviewModal');
    if (!modal) return;
    modal.querySelector('.modal-title').textContent = tpl.name;

    const isPortrait = tpl.orientation === 'Portrait';
    const bg = tpl.bgConfig || { type: 'color', color: '#FFF' };
    const bgStyle = bg.type === 'gradient' && bg.gradient ? bg.gradient : bg.color || '#FFFFFF';

    let innerHTML = `
      <div class="certificate-preview" style="background: var(--designer-bg); padding:20px; overflow:auto;">
        <div class="certificate-inner ${isPortrait ? 'portrait' : 'landscape'}" style="
          background: ${bgStyle};
          background-size: ${bg.size || 'cover'};
          background-position: center;
          background-repeat: ${bg.size === 'repeat' ? 'repeat' : 'no-repeat'};
          ${bg.image ? `background-image: url('${bg.image}');` : ''}
          opacity: ${bg.opacity || 1.0};
          border-radius: var(--radius-lg);
          position:relative;
          border: ${bg.borderWidth ? `${bg.borderWidth}px ${bg.borderStyle || 'solid'} ${bg.borderColor || '#1565C0'}` : 'none'}
        ">
    `;

    // Render elements if customized
    if (tpl.elements && tpl.elements.length > 0) {
      tpl.elements.forEach(item => {
        const opacity = item.opacity !== undefined ? item.opacity : 1.0;
        if (item.type === 'text') {
          innerHTML += `
            <div style="
              position: absolute;
              left: ${item.x}px;
              top: ${item.y}px;
              width: ${item.width}px;
              height: ${item.height}px;
              transform: rotate(${item.rotation || 0}deg);
              opacity: ${opacity};
              font-family: '${item.fontFamily}', sans-serif;
              font-size: ${item.fontSize}px;
              font-weight: ${item.fontWeight};
              font-style: ${item.fontStyle};
              text-decoration: ${item.textDecoration};
              color: ${item.color};
              text-align: ${item.textAlign};
              letter-spacing: ${item.letterSpacing}px;
              line-height: ${item.lineHeight};
              text-transform: ${item.textTransform};
              text-shadow: ${item.textShadow};
              border: ${item.borderWidth ? `${item.borderWidth}px solid ${item.borderColor || '#000'}` : 'none'};
              border-radius: ${item.borderRadius || 0}px;
            ">${item.content}</div>
          `;
        } else if (item.type === 'image') {
          innerHTML += `
            <img src="${item.content || 'https://via.placeholder.com/' + item.width + 'x' + item.height + '?text=' + item.placeholder}" style="
              position: absolute;
              left: ${item.x}px;
              top: ${item.y}px;
              width: ${item.width}px;
              height: ${item.height}px;
              transform: rotate(${item.rotation || 0}deg);
              opacity: ${opacity};
              object-fit: contain;
            " />
          `;
        }
      });
    } else {
      // Basic empty fallback description
      innerHTML += `
        <div class="certificate-company" style="color:var(--primary); font-weight:700;">SAMUDHRA TECH SOLUTIONS</div>
        <div class="certificate-title" style="margin-top:20px;">${tpl.name}</div>
        <div class="certificate-text" style="margin:24px auto;">${tpl.description || 'Certificate of Completion'}</div>
        <p style="color:var(--text-muted); font-size:12px; margin-top:40px;">This template has no canvas elements yet. Click "Design" to configure.</p>
      `;
    }

    innerHTML += `
        </div>
      </div>
    `;

    modal.querySelector('.modal-body').innerHTML = innerHTML;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  },

  duplicateTemplate(id) {
    const tpl = this.templates.find(t => t.id === id);
    if (!tpl) return;
    
    const copy = JSON.parse(JSON.stringify(tpl));
    copy.id = Utils.generateId();
    copy.name = `${tpl.name} (Copy)`;
    copy.createdAt = new Date().toISOString().split('T')[0];
    copy.lastUpdated = copy.createdAt;
    
    this.templates.unshift(copy);
    Utils.setToStorage('templates', this.templates);
    
    this.applyFilters();
    this.render();
    showToast('Duplicated', 'Template duplicated successfully', 'success');
  },

  confirmDelete(id) {
    const tpl = this.templates.find(t => t.id === id);
    if (!tpl) return;
    const modal = document.getElementById('confirmModal');
    if (!modal) return;
    modal.querySelector('.modal-title').textContent = 'Delete Template';
    modal.querySelector('.modal-body').innerHTML = `
      <div style="text-align:center">
        <div style="font-size:48px;color:var(--error);margin-bottom:16px"><i class="fas fa-exclamation-triangle"></i></div>
        <h3 style="margin-bottom:8px">Delete "${tpl.name}"?</h3>
        <p style="color:var(--text-muted)">This action cannot be undone. The template and all associated data will be permanently removed.</p>
      </div>
    `;
    modal.querySelector('.modal-footer').innerHTML = `
      <button class="btn btn-outline" onclick="document.getElementById('confirmModal').classList.remove('active');document.body.style.overflow=''">Cancel</button>
      <button class="btn btn-danger" onclick="Templates.deleteTemplate('${id}')"><i class="fas fa-trash"></i> Delete Permanently</button>
    `;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  },

  deleteTemplate(id) {
    this.templates = this.templates.filter(t => t.id !== id);
    Utils.setToStorage('templates', this.templates);
    document.getElementById('confirmModal').classList.remove('active');
    document.body.style.overflow = '';
    
    this.applyFilters();
    this.render();
    showToast('Deleted', 'Template has been removed', 'success');
  }
};

window.Templates = Templates;
