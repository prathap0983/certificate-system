/* ============================================
   UTILITY FUNCTIONS
   ============================================ */
const Utils = {
  generateId() {
    return 'id_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  },

  generateCertificateNumber() {
    const prefix = 'STC';
    const year = new Date().getFullYear();
    const num = Math.floor(Math.random() * 90000) + 10000;
    return `${prefix}${year}${num}`;
  },

  formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  },

  formatDateTime(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  },

  truncate(str, len = 50) {
    if (!str) return '';
    return str.length > len ? str.substring(0, len) + '...' : str;
  },

  capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  },

  isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },

  isValidPhone(phone) {
    return /^[\d\s\-+()]{7,15}$/.test(phone);
  },

  debounce(fn, delay = 300) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  },

  getFromStorage(key) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch { return null; }
  },

  setToStorage(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch { return false; }
  },

  removeFromStorage(key) {
    try {
      localStorage.removeItem(key);
      return true;
    } catch { return false; }
  },

  getQueryParam(param) {
    const url = new URL(window.location.href);
    return url.searchParams.get(param);
  },

  navigateTo(page) {
    window.location.href = page;
  },

  getInitials(name) {
    if (!name) return '?';
    return name.split(' ').map(w => w.charAt(0)).join('').toUpperCase().substring(0, 2);
  },

  exportToCSV(data, filename) {
    if (!data || !data.length) return;
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => headers.map(h => {
        const val = row[h] || '';
        return `"${String(val).replace(/"/g, '""')}"`;
      }).join(','))
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  },

  exportToExcel(data, filename) {
    this.exportToCSV(data, filename);
  },

  printElement(elementId) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const clone = el.cloneNode(true);
    clone.style.transform = 'none';
    clone.style.margin = '0 auto';
    const html = clone.outerHTML;
    const win = window.open('', '_blank');
    win.document.write(`
      <html><head>
        <title>Print</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/components.css">
        <link rel="stylesheet" href="css/animations.css">
        <style>
          @media print{body{background:white!important;margin:0;padding:0}}
          .certificate-a4-canvas{margin:0 auto}
        </style>
      </head><body>${html}</body></html>
    `);
    win.document.close();
    setTimeout(() => win.print(), 500);
  },

  downloadPDF(elementId, filename) {
    alert(`PDF download placeholder: ${filename}.pdf\n(Integrate with jsPDF or backend for production)`);
  },

  showSkeleton(containerId, count = 3) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = '';
    for (let i = 0; i < count; i++) {
      const skeleton = document.createElement('div');
      skeleton.className = 'skeleton-card-item';
      skeleton.innerHTML = `
        <div class="skeleton skeleton-avatar"></div>
        <div class="skeleton-lines">
          <div class="skeleton skeleton-line"></div>
          <div class="skeleton skeleton-line"></div>
          <div class="skeleton skeleton-line"></div>
        </div>
      `;
      container.appendChild(skeleton);
    }
  },

  animateCounter(el, target, duration = 1000) {
    let start = 0;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        el.textContent = target;
        clearInterval(timer);
      } else {
        el.textContent = Math.floor(start);
      }
    }, 16);
  }
};

/* === API Service (ready for Spring Boot backend) === */
class ApiService {
  constructor(baseUrl = 'http://localhost:8080/api') {
    this.baseUrl = baseUrl;
  }

  async get(endpoint) {
    try {
      const res = await fetch(`${this.baseUrl}${endpoint}`);
      if (!res.ok) throw new Error(`GET ${endpoint} failed`);
      return await res.json();
    } catch (err) {
      console.warn(`API GET ${endpoint} failed, using local data:`, err.message);
      return null;
    }
  }

  async post(endpoint, data) {
    try {
      const res = await fetch(`${this.baseUrl}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error(`POST ${endpoint} failed`);
      return await res.json();
    } catch (err) {
      console.warn(`API POST ${endpoint} failed, using local data:`, err.message);
      return null;
    }
  }

  async put(endpoint, data) {
    try {
      const res = await fetch(`${this.baseUrl}${endpoint}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error(`PUT ${endpoint} failed`);
      return await res.json();
    } catch (err) {
      console.warn(`API PUT ${endpoint} failed, using local data:`, err.message);
      return null;
    }
  }

  async delete(endpoint) {
    try {
      const res = await fetch(`${this.baseUrl}${endpoint}`, { method: 'DELETE' });
      if (!res.ok) throw new Error(`DELETE ${endpoint} failed`);
      return true;
    } catch (err) {
      console.warn(`API DELETE ${endpoint} failed, using local data:`, err.message);
      return null;
    }
  }
}

const API = new ApiService();
